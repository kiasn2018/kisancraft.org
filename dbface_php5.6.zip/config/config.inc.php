<?php
// the cache provider, db
$config['cache_provider'] = 'db';
// the default schema cache is never expired (seconds) 0: disable cache
$config['cache_schema'] = -1;
// report never auto expired (seconds), 3600 means 1 hour, 0: disable cache
$config['cache_app'] = 0;
$config['ExecTimeLimit'] = 60;
$config['MemoryLimit'] = "64M";
// hide the online support widget
$config['enable_onlinesupport'] = TRUE;
// session save path, comment this, if you want use the default folder in php.ini
$config['sess_save_path'] = APPPATH.DIRECTORY_SEPARATOR."cache";
// $config['sess_cookie_name']		= 'sess_';
// chart theme:
// empty: default theme, also support macarons and  infographic
$config['chart_theme'] = 'macarons';
// default category name
$config['default_category_name'] = 'Default';
// default data category name
$config['default_data_category_name'] = 'Data';
// menu style: normal or horizontal
// you can also overwrite this settings in System Settings (dropped)
$config['menu_style'] = 'normal';
// available chart provider:
// default   : the default implementation
// highcharts: Require highcharts License, free for non-commercial project (dropped)
// highcharts not support since V6
$config['chart_provider'] = 'default';
// Use your Google Appkey to generate Google Map
$config['google.appkey'] = 'AIzaSyBImzyugJzPWt1cQC0bWbUznaVUIc805eU';
// the max rows for picked sample data
$config['max_sample_rows'] = 100;
// Enable error_report, the error does not include any app data
$config['enable_error_report'] = TRUE;
// define the default title of DbFace
$config['df.title'] = 'DbFace - Online Application Builder for SQL Database.';
// the assets URL
if ($config['production']) {
  $config['df.static'] = "//v7.dbface.com/static";
}

// product base URL, if FALSE, we will detect automatically
$config['product_base_url'] = FALSE;
// checkpoint max_size bytes
$config['cp_max_size'] = 1024;
// SSO url, do not modify this
$config['sso_url_path'] = 'iframe';
// enable / disable gravatar
$config['enable_gravatar'] = TRUE;
// disable PHP report
$config['disable_phpreport'] = FALSE;
// hide edit application
$config['disable_sql_edit_application'] = FALSE;
$config['disable_public_access_parameters'] = FALSE;
$config['Access-Control-Allow-Origin'] = FALSE;
// DbFace only access public schema, you can also switch to other schema for pgsql database only
// Since V6.6, you can add schema option for pgsql database
$config['pgsql_default_schema'] = FALSE;
// if password mismatch 3 times, the ip will blocked 24 hours, set FALSE disable this feature
$config['daily_retry_login_times'] = 50;
$config['daily_retry_login_time_duration'] = 86400;
// the max num of last opened apps
$config['history_app_num'] = 6;
// max favorite num
$config['favorite_app_num'] = 10;
// let dbface create database in your hostdb
$config['enable_createdatabase'] = TRUE;
// If you want to use DbFace to create database for you, enable this
/*
$config['hostdb'] = array(
  'dsn'	=> '',
  'hostname'=> 'localhost',
  'username'=> 'root',
  'password'=> 'root',
  'database'=> 'test',
  'dbdriver' => 'mysqli',
  'dbprefix' => '',
  'pconnect' => FALSE,
  'db_debug' => FALSE,
  'cache_on' => FALSE,
  'cachedir' => '',
  'char_set'=> 'utf8',
  'dbcollat' => 'utf8_general_ci',
  'swap_pre' => '',
  'autoinit' => FALSE,
  'stricton' => FALSE,
  'failover' => array()
);
*/
// whether creating new database user for the newly created database
$config['create_sperated_user_for_hostdb'] = TRUE;
// the created database user host, % for any location, or set ip address for security
// $config['hostdb_user_host'] = 'localhost';
// predefined variables
$config['predefined_variables'] = FALSE;
// use this config to encrypt the connection password
// set to FALSE, will use plain text to store the connection password
$config['db_password_encrypt'] = FALSE;
// Login logo settings
// position: left | right | center
// array(
//   'url' => '//www.dbface.com',
//   'position' => 'right',
//   'img' => $config['df.static'].'/website/dbface_logo.png'
// );
$config['login_logo_settings'] = FALSE;

// Additional css files (for remote customization theme)
// you can get the css url from DbFace Support Team (Licensed User + Gold Support)
// the css file will include to override the default style
$config['customer_additonal_css'] = FALSE;
// default skin, if you set this entry via ui, it will override this value
$config['default_skin'] = FALSE;
// default tooltip border width
$config['chart_tooltip_border_width'] = 1;
// allow forget password on the login page for all users
$config['allow_reset_password_on_premise'] = FALSE;
// the email sending preference for sending password reset link or report
// find referece from http://www.dbface.com/ticket/kb/
$config['email_settings'] = array();
// csv exporting settings
$config['export_csv_settings'] = FALSE;
// enable markdown for html report
// TRUE: use markdown to parse the code, FALSE: only template mode
$config['enable_markdown_htmlreport'] = FALSE;
// enable marketplace
$config['enable_marketplace'] = TRUE;
// marketplace URL
$config['marketplace_url'] = 'http://localhost/dbface';

// marketplace URL
if ($config['production']) {
  $config['marketplace_url'] = 'http://v7.dbface.com';
}

// live preview
// TRUE: change the options will reload the app preview
// FALSE: Click the preview button to lauch app preview
$config['enable_live_preview'] = TRUE;

// USE CAUTIOUS
// force reset the username & password to this entry strng
// if you have forgot the admin password, please set this entry to reset password
// and do not forget recover to false 
// sample
// $config['force_reset_accounts'] = array(
//   array('email'=> 'admin@dbface.com', 'passowrd'=> 'my new password')
// );
$config['force_reset_accounts'] = FALSE;
