CREATE TABLE IF NOT EXISTS dc_user (
  userid        serial PRIMARY KEY,
  creatorid     integer DEFAULT 0,
  email         varchar(255) NOT NULL,
  name          varchar(64) NOT NULL,
  password      varchar(32),
  permission    smallint DEFAULT 0,
  status        smallint DEFAULT 0,
  regip         varchar(32),
  regdate       integer,
  expiredate    integer,
  plan          varchar(32) DEFAULT 'level1'
);

CREATE TABLE IF NOT EXISTS dc_conn (
  connid     serial PRIMARY KEY,
  creatorid  integer,
  name       varchar(255) NOT NULL,
  hostname   varchar(255) NOT NULL,
  username   varchar(32) default NULL,
  password   varchar(128) NOT NULL,
  database   varchar(128) NOT NULL,
  dbdriver   varchar(32) default NULL,
  dbprefix   varchar(16) default NULL,
  pconnect   smallint default 0,
  char_set   varchar(32) default NULL,
  dbcollat   varchar(32) default NULL,
  swap_pre   varchar(32) default NULL,
  stricton   varchar(32) default NULL,
  port       varchar(32) default NULL,  
  createdate integer
);

CREATE TABLE IF NOT EXISTS dc_category (
  categoryid serial PRIMARY KEY,
  creatorid  integer,
  name       varchar(255) NOT NULL,
  icon       varchar(255) DEFAULT NULL,
  parentid   integer
);

CREATE TABLE IF NOT EXISTS dc_app (
  appid           serial PRIMARY KEY,
  connid          integer,
  creatorid       integer,
  type            varchar(32) NOT NULL,
  name            varchar(64) default NULL,
  title           varchar(64) default NULL,
  "desc"            varchar(255) default NULL,
  categoryid      integer,
  form            text default NULL,
  form_org        text default NULL,
  script          text default NULL,
  script_org      text default NULL,
  scripttype      varchar(32) default NULL,
  confirm         text default NULL,
  format          varchar(32) default 'tabular',
  options         text default NULL,
  status          varchar(16) default 'draft',
  embedcode       varchar(64) default NULL,
  createdate      integer
);

CREATE TABLE IF NOT EXISTS dc_app_permission (
  appid           INTEGER,
  userid          INTEGER
);

CREATE TABLE IF NOT EXISTS dc_uservisitlog (
  userid  integer,
  type    varchar(32) NOT NULL,
  module  varchar(32) default NULL,
  action  varchar(32) default NULL,
  appid   integer,
  message text default NULL,
  url     varchar(255) default NULL,
  ip      varchar(15) default NULL,
  show    smallint,
  date    integer
);

CREATE TABLE IF NOT EXISTS dc_customcss (
  creatorid   integer,
  css         text default NULL,
  date        integer
);

CREATE TABLE IF NOT EXISTS dc_customjs (
  creatorid   integer,
  js          text default NULL,
  date        integer
);

CREATE TABLE IF NOT EXISTS dc_user_options (
  creatorid integer,
  name      varchar(64) NOT NULL,
  type      varchar(16) default NULL,
  value     varchar(64) default NULL
);

CREATE TABLE IF NOT EXISTS dc_app_options (
  creatorid INTEGER,
  connid    INTEGER,
  appid     INTEGER,
  "key"       varchar(64) NOT NULL,
  "type"      varchar(64) NOT NULL,
  "value"     text default NULL
);

CREATE TABLE IF NOT EXISTS dc_cache (
  creatorid   INTEGER,
  "type"        varchar(32) NOT NULL,
  datatype    varchar(32) default 'string',
  name        varchar(255) default NULL,
  "value"       text default NULL,
  date        INTEGER
);

CREATE TABLE IF NOT EXISTS dc_user_dashboard (
  iddashboard varchar(16) NOT NULL,
  menu        varchar(64) default 'Dashboard',
  name        varchar(100) DEFAULT NULL,
  layout      text DEFAULT NULL,
  embedcode   varchar(64) default NULL
);

CREATE TABLE IF NOT EXISTS dc_tablelinks (
  connid INTEGER NOT NULL,
  srctable varchar(128) NOT NULL,
  srccolumn varchar(128) NOT NULL,
  dsttable varchar(128) NOT NULL,
  dstcolumn varchar(128) NOT NULL,
  creatorid INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS dc_code (
  creatorid INTEGER NOT NULL,
  connid INTEGER NOT NULL,
  api varchar(128) NOT NULL,
  "public" smallint DEFAULT 0,
  filename varchar(128) NOT NULL,
  content TEXT NOT NULL,
  date INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS dc_parameter (
  creatorid INTEGER NOT NULL,
  connid INTEGER DEFAULT 0,
  name varchar(64) NOT NULL,
  "type" smallint DEFAULT 0,
  "value" TEXT NOT NULL,
  cached TEXT NOT NULL,
  ttl INTEGER DEFAULT 0,
  "public" INTEGER DEFAULT 0,
  lastupdate INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS dc_app_log (
  creatorid INTEGER NOT NULL,
  appid INTEGER DEFAULT 0,
  name varchar(64) DEFAULT NULL,
  "type" varchar(64) DEFAULT NULL,
  "value" TEXT NOT NULL,
  date INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS dc_checkpoint (
  cpid SERIAL PRIMARY KEY,
  appid INTEGER DEFAULT 0,
  paramkey varchar(64) default NULL,
  recorddate INTEGER,
  content text NOT NULL
);
