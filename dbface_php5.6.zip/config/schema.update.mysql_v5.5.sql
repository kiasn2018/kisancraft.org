ALTER TABLE dc_category ADD `icon` varchar(255) DEFAULT NULL; 
