<?php
// this function will always executed before page rendered, if defined
if (!function_exists('_hook_fc_start_')){
  function _hook_fc_start_() {
    date_default_timezone_set('America/Los_Angeles');
    define('ENVIRONMENT', 'production');
  }
}

// check controller here
// login_permission 0: admin, 1: developer, 9: user
function _check_permission($controller, $action, $login_permission) {
  if ($login_permission == 9) {
    $user_disallowed_controllers = array(
      'Structure', 'Sql', 'TableStructure', 'Duplicatetable', 'CssEditor', 'Conn', 'Appbuilder'
    );
    if (in_array($controller, $user_disallowed_controllers)) {
      return FALSE;
    }
  }

  if ($login_permission == 1) {
    if (($controller == 'Conn' || $controller == 'Account') && $action == 'index') {
      return FALSE;
    }
  }
  return TRUE;
}

// format your resultset before displaying, if defined
function _hook_queryresult_($appid, &$fields, &$resultset) {

}

// filter or orering users list in dashboard page
function sort_subaccounts($users) {
    return $users;
}

/**
 * sort menu apps
 */
function sort_sidemenu($categoryapps) {
	/*
	$result = array();
	foreach($categoryapps as $key => $apps) {
	  usort($apps, function($a, $b) {
		return strcmp($a["name"], $b["name"]);
	  });
	  $result[$key] = $apps;
	}
	return $result;
	*/
	return $categoryapps;
}

// implement my own login
// Return: array("userid"=>'', "username"=>'', 'permission'=>"admin|developer|user")
// Return: FALSE, use DbFacePHP user system
function api_login() {
  return FALSE;
}

// define my own logout
function api_logout() {
  // TODO:
}

// date format function
// Return True : Processed by this hook function
// Return FALSE: Use internal implementation, not processed
function api_date_format($db, $format, $select, $label) {
  return FALSE;
}

// You can specifiy your own table loop up query for current db
// DbFace will look all TABLE_NAME column for each row
function api_table_lookup($driver, $sub_driver) {
  return FALSE;
}

// customization your own table lookup query, if already defined the api_table_lookup, this function will be ignored
// RETURN FALSE, use the default table lookup query
function api_get_table_lookup_query($db) {
  return FALSE;
}

// define your predefined variables for application templates
// the return value should be associate array
function api_get_predefined_variables() {
  return FALSE;
}
?>
