CREATE TABLE IF NOT EXISTS dc_user (
  userid        INTEGER PRIMARY KEY,
  creatorid     INTEGER DEFAULT 0,
  email         TEXT,
  name          TEXT UNIQUE,
  password      TEXT,
  permission    TINYINT DEFAULT 0,
  status        TINYINT DEFAULT 0,
  regip         TEXT,
  regdate       INTEGER,
  expiredate    INTEGER,
  plan          TEXT DEFAULT "level1",
  groupid       TEXT DEFAULT ""
);

CREATE TABLE IF NOT EXISTS dc_conn (
  connid     INTEGER PRIMARY KEY,
  creatorid  INTEGER,
  name       TEXT,
  hostname   TEXT,
  username   TEXT,
  password   TEXT,
  database   TEXT,
  dbdriver   TEXT,
  dbprefix   TEXT,
  pconnect   TINYINT default 0,
  char_set   TEXT,
  dbcollat   TEXT,
  swap_pre   TEXT,
  stricton   TEXT,
  port       TEXT,  
  createdate INTEGER
);

CREATE TABLE IF NOT EXISTS dc_category (
  categoryid INTEGER PRIMARY KEY,
  creatorid  INTEGER,
  name       TEXT,
  icon       TEXT,
  parentid   INTEGER
);

CREATE TABLE IF NOT EXISTS dc_app (
  appid           INTEGER PRIMARY KEY,
  connid          INTEGER,
  creatorid       INTEGER,
  type            TEXT,
  name            TEXT,
  title           TEXT,
  desc            TEXT,
  categoryid      INTEGER,
  form            TEXT,
  form_org        TEXT,
  script          TEXT,
  script_org      TEXT,
  scripttype      TEXT,
  confirm         TEXT,
  format          TEXT DEFAULT "tabular",
  options         TEXT,
  status          TEXT DEFAULT "draft",
  embedcode       TEXT,
  createdate      INTEGER
);

CREATE TABLE IF NOT EXISTS dc_app_permission (
  appid           INTEGER,
  userid          INTEGER
);

CREATE TABLE IF NOT EXISTS dc_uservisitlog (
  userid  INTEGER,
  type    TEXT,
  module  TEXT,
  action  TEXT,
  appid   INTEGER,
  message TEXT,
  url     TEXT,
  ip      TEXT,
  show    TINYINT,
  date    INTEGER
);

CREATE TABLE IF NOT EXISTS dc_customcss (
  creatorid   INTEGER,
  css         TEXT,
  date        INTEGER
);

CREATE TABLE IF NOT EXISTS dc_customjs (
  creatorid   INTEGER,
  js          TEXT,
  date        INTEGER
);

CREATE TABLE IF NOT EXISTS dc_user_options (
  creatorid INTEGER,
  name      TEXT,
  type      TEXT,
  value     TEXT
);

CREATE TABLE IF NOT EXISTS dc_app_options (
  creatorid INTEGER,
  connid    INTEGER,
  appid     INTEGER,
  key      TEXT,
  type     TEXT,
  value     TEXT
);

CREATE TABLE IF NOT EXISTS dc_cache (
  creatorid   INTEGER,
  type        TEXT,
  datatype    TEXT default 'string',
  name        TEXT,
  value       TEXT,
  date        INTEGER
);

CREATE TABLE IF NOT EXISTS dc_user_dashboard (
  iddashboard TEXT NOT NULL,
  menu        TEXT default 'Dashboard',
  name        TEXT,
  layout      TEXT DEFAULT NULL,
  embedcode   TEXT
);

CREATE TABLE IF NOT EXISTS dc_tablelinks (
  connid INTEGER NOT NULL,
  srctable TEXT NOT NULL,
  srccolumn TEXT NOT NULL,
  dsttable TEXT NOT NULL,
  dstcolumn TEXT NOT NULL,
  creatorid INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS dc_code (
  creatorid INTEGER NOT NULL,
  connid INTEGER NOT NULL,
  api TEXT NOT NULL,
  public INTEGER DEFAULT 0,
  filename TEXT NOT NULL,
  content TEXT NOT NULL,
  date INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS dc_parameter (
  creatorid INTEGER NOT NULL,
  connid INTEGER DEFAULT 0,
  name TEXT NOT NULL,
  type INTEGER DEFAULT 0,
  value TEXT NOT NULL,
  cached TEXT NOT NULL,
  ttl INTEGER DEFAULT 0,
  public INTEGER DEFAULT 0,
  lastupdate INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS dc_app_log (
  creatorid INTEGER NOT NULL,
  appid INTEGER DEFAULT 0,
  name TEXT DEFAULT NULL,
  type TEXT DEFAULT NULL,
  value TEXT NOT NULL,
  date INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS dc_conn_option (
  creatorid INTEGER NOT NULL,
  connid INTEGER DEFAULT 0,
  name TEXT DEFAULT NULL,
  type TEXT DEFAULT NULL,
  value TEXT NOT NULL,
  date INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS dc_checkpoint (
  cpid INTEGER PRIMARY KEY,
  appid INTEGER DEFAULT 0,
  paramkey TEXT DEFAULT NULL,
  recorddate INTEGER NOT NULL,
  content TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS dc_product (
  pid INTEGER PRIMARY KEY,
  creatorid INTEGER NOT NULL,
  name TEXT DEFAULT NULL,
  url TEXT DEFAULT NULL,
  description TEXT DEFAULT NULL,
  theme TEXT DEFAULT NULL,
  logintype INTEGER DEFAULT 0,
  brand TEXT DEFAULT NULL,
  brandurl TEXT DEFAULT NULL,
  menutype INTEGER DEFAULT 0,
  menuposition INTEGER DEFAULT 0,
  settings TEXT DEFAULT NULL,
  apps TEXT DEFAULT NULL,
  active INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS dc_template (
  creatorid INTEGER NOT NULL,
  filename TEXT NOT NULL,
  content TEXT NOT NULL,
  date INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS dc_sys_template (
  creatorid INTEGER NOT NULL,
  filename TEXT NOT NULL,
  content TEXT NOT NULL,
  date INTEGER NOT NULL
);


CREATE TABLE IF NOT EXISTS dc_market_item (
  itemkey TEXT NOT NULL,
  creatorid INTEGER NOT NULL,
  name TEXT NOT NULL,
  type TEXT NOT NULL,
  thumb TEXT DEFAULT NULL,
  summary TEXT DEFAULT NULL,
  description TEXT DEFAULT NULL,
  price INTEGER NOT NULL DEFAULT 0,
  status INTEGER NOT NULL DEFAULT 0,
  target TEXT NOT NULL,
  param1 TEXT DEFAULT NULL,
  createdate INTEGER NOT NULL,
  updatedate INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS dc_market_vendor (
  creatorid INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  email TEXT NOT NULL,
  avatar TEXT DEFAULT NULL,
  clientcode TEXT DEFAULT NULL,
  refer TEXT DEFAULT NULL,
  userid INTEGER DEFAULT 0,
  date INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS dc_market_attachment (
  itemkey TEXT NOT NULL,
  creatorid INTEGER NOT NULL,
  content TEXT NOT NULL,
  createdate INTEGER NOT NULL,
  updatedate INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS dc_market_tag (
  itemkey TEXT NOT NULL,
  tag TEXT NOT NULL,
  date INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS dc_market_screenshot (
  itemkey TEXT NOT NULL,
  image TEXT NOT NULL,
  date INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS dc_market_follow (
  itemkey TEXT NOT NULL,
  creatorid INTEGER NOT NULL,
  date INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS dc_market_order (
  itemkey TEXT NOT NULL,
  creatorid INTEGER NOT NULL,
  date INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS dc_usergroup (
  groupid TEXT NOT NULL,
  name TEXT NOT NULL,
  creatorid INTEGER NOT NULL,
  date INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS dc_usergroup_permission (
  groupid TEXT NOT NULL,
  appid INTEGER NOT NULL,
  date INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS dc_crontab (
  cronid TEXT NOT NULL,
  code TEXT NOT NULL,
  type INTEGER DEFAULT 0,
  interval INTEGER DEFAULT 0,
  hour INTEGER DEFAULT 0,
  minute INTEGER DEFAULT 0,
  creatorid INTEGER NOT NULL,
  date INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS dc_crontab_log (
  cronid TEXT NOT NULL,
  startdate INTEGER NOT NULL,
  enddate INTEGER NOT NULL,
  status INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS dc_user_app_favorite (
  userid INTEGER NOT NULL,
  appid INTEGER NOT NULL,
  date INTEGER NOT NULL
);


