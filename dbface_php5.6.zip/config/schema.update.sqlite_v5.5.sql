ALTER TABLE dc_category ADD icon TEXT; 
